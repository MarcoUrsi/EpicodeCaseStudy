CREATE DATABASE DB_Lottomatica;

--Importare dati da file csv

--tabella Geography

SELECT *
FROM Geography

-- Modifica del tipo di dati delle colonne GeographyKey, City, Region e Country 

ALTER TABLE Geography
ALTER COLUMN GeographyKey NVARCHAR(25) NOT NULL;

ALTER TABLE Geography
ALTER COLUMN City NVARCHAR(50);

ALTER TABLE Geography
ALTER COLUMN Region NVARCHAR(50);

ALTER TABLE Geography
ALTER COLUMN Country NVARCHAR(25);

-- Colonna GeographyKey come chiave primaria

ALTER TABLE Geography
ADD CONSTRAINT PK_Geography PRIMARY KEY (GeographyKey);

--tabella Customer

SELECT *
FROM Customer

-- Modifica del tipo di dati delle colonne CustomerKey, GeographyKey, Firstname, Lastname, Birthdate, Age, EmailAdress 

ALTER TABLE Customer
ALTER COLUMN CustomerKey NVARCHAR(25) NOT NULL;

ALTER TABLE Customer
ALTER COLUMN GeographyKey NVARCHAR(25) NOT NULL;

ALTER TABLE Customer
ALTER COLUMN FirstName NVARCHAR(25);

ALTER TABLE Customer
ALTER COLUMN LastName NVARCHAR(25);

ALTER TABLE Customer
ALTER COLUMN Birthday DATE;

ALTER TABLE Customer
ALTER COLUMN EmailAdress NVARCHAR(50);

ALTER TABLE Customer
ALTER COLUMN Age INT;

ALTER TABLE Customer
ALTER COLUMN Gender NVARCHAR(25);

-- Colonna CustomerKey come chiave primaria e GeographyKey come chiave esterna

ALTER TABLE Customer
ADD CONSTRAINT PK_Customer PRIMARY KEY (CustomerKey);

ALTER TABLE Customer
ADD CONSTRAINT FK_Customer_Geography_GeographyKey 
FOREIGN KEY (GeographyKey) REFERENCES Geography (GeographyKey);

--tabella BetsHeader

SELECT *
FROM BetsHeader

-- Modifica del tipo di dati delle colonne BetKey, CustomerKey, BetDate

ALTER TABLE BetsHeader
ALTER COLUMN BetKey NVARCHAR(25) NOT NULL;

ALTER TABLE BetsHeader
ALTER COLUMN CustomerKey NVARCHAR(25) NOT NULL;

ALTER TABLE BetsHeader
ALTER COLUMN BetDate DATE;

-- Colonna BetKey come chiave primaria e CustomerKey come chiave esterna

ALTER TABLE BetsHeader
ADD CONSTRAINT PK_BetsHeader PRIMARY KEY (BetKey);

ALTER TABLE BetsHeader
ADD CONSTRAINT FK_BetsHeader_Customer_CustomerKey 
FOREIGN KEY (CustomerKey) REFERENCES Customer (CustomerKey);

--tabella BetsDetail

SELECT *
FROM BetsDetail

-- Modifica del tipo di dati delle colonne BetNumber, BetLineNumber, MoneyWagered, Quantity, GameKey, CashWin

ALTER TABLE BetsDetail
ALTER COLUMN BetNumber NVARCHAR(25) NOT NULL;

ALTER TABLE BetsDetail
ALTER COLUMN BetLineNumber NVARCHAR(25) NOT NULL;

ALTER TABLE BetsDetail
ALTER COLUMN MoneyWagered money;

ALTER TABLE BetsDetail
ALTER COLUMN Quantity INT;

ALTER TABLE BetsDetail
ALTER COLUMN GameKey NVARCHAR(25);

ALTER TABLE BetsDetail
ALTER COLUMN CashWin money;


-- Colonna OrdeNumber&OrderLineNumber come chiave primaria e ProductKey come chiave esterna

ALTER TABLE BetsDetail
ADD CONSTRAINT PK_BetsDetail_BetNumber_BetLineNumber PRIMARY KEY (BetNumber, BetLineNumber);

ALTER TABLE BetsDetail
ADD CONSTRAINT FK_BetsDetail_Game_GameKey 
FOREIGN KEY (GameKey) REFERENCES Game (GameKey);

--tabella Game

SELECT *
FROM Game

-- Modifica del tipo di dati delle colonne ProductKey, ProductName, ProductCost, SubCategoryKey
ALTER TABLE Game
ALTER COLUMN GameKey NVARCHAR(25) NOT NULL;

ALTER TABLE Game
ALTER COLUMN GameName NVARCHAR(25);

ALTER TABLE Game
ALTER COLUMN GameCost FLOAT;

ALTER TABLE Game
ALTER COLUMN GameSubcategoryKey NVARCHAR(25) NOT NULL;


-- Colonna GameKey come chiave primaria e gameSubcategoryKey come chiave esterna

ALTER TABLE Game
ADD CONSTRAINT PK_Game PRIMARY KEY (GameKey);

ALTER TABLE Game
ADD CONSTRAINT FK_Game_GameSubcateory_GameSubcategoryKey 
FOREIGN KEY (GameSubcategoryKey) REFERENCES GameSubcategory (GameSubcategoryKey);

--tabella GameSubcategory

SELECT *
FROM GameSubcategory

-- Modifica del tipo di dati delle colonne GameSubcategoryKey, GameSubcategoryName, GameCategoryKey

ALTER TABLE GameSubcategory
ALTER COLUMN GameSubcategoryKey NVARCHAR(25) NOT NULL;

ALTER TABLE GameSubcategory
ALTER COLUMN GameSubcategoryName NVARCHAR(25);

ALTER TABLE GameSubcategory
ALTER COLUMN GameCategoryKey NVARCHAR(25) NOT NULL;


-- Colonna SubcategoryKey come chiave primaria e CategoryKey come chiave esterna

ALTER TABLE GameSubcategory
ADD CONSTRAINT PK_GameSubcategory PRIMARY KEY (GameSubcategoryKey);

ALTER TABLE GameSubcategory
ADD CONSTRAINT FK_GameSubcateory_GameCategory_GameCategoryKey 
FOREIGN KEY (GameCategoryKey) REFERENCES GameCategory (GameCategoryKey);

--tabella GameCategory

SELECT *
FROM GameCategory

-- Modifica del tipo di dati delle colonne CategoryKey e CategoryName

ALTER TABLE GameCategory
ALTER COLUMN GameCategoryKey NVARCHAR(25) NOT NULL;

ALTER TABLE GameCategory
ALTER COLUMN GameCategoryName NVARCHAR(25);


-- Colonna categoryKey come chiave primaria 
ALTER TABLE GameCategory
ADD CONSTRAINT PK_GameCategory PRIMARY KEY (GameCategoryKey);


--Query esempio
--1  totale soldi scommesse
SELECT SUM(s.MoneyWagered*s.Quantity) as BetsAmount
FROM BetsDetail as s

--2  Profit, totale scommesse meno percentuale costi e vincite giocatori
SELECT SUM(s.MoneyWagered*s.Quantity)-SUM(s.MoneyWagered*s.Quantity*p.GameCost)-SUM(CashWin) as Profit
FROM BetsDetail as s
INNER JOIN Game as p
ON s.GameKey = p.GameKey

--3 fatturato per nome gioco, ordinamento decrescente
SELECT SUM(s.MoneyWagered*s.Quantity) as BetsAmount, p.GameName
FROM BetsDetail as s
INNER JOIN Game as p
ON s.GameKey = p.GameKey
GROUP BY p.GameName
ORDER BY BetsAmount DESC

--4 elenco clienti con ammontare scommesse per cliente, odinamento decrescente
SELECT CONCAT(c.FirstName, c.LastName) as NameCustomer, SUM(s.MoneyWagered*s.Quantity) as BetsAmount
FROM BetsDetail as s
INNER JOIN BetsHeader as o
ON s.BetNumber = o.BetKey
INNER JOIN Customer as c
ON o.CustomerKey = c.CustomerKey
GROUP BY c.FirstName, c.LastName 
ORDER BY BetsAmount DESC

--5 lista clienti nella citt� di Roma
SELECT CONCAT(c.FirstName, c.LastName) as NameCustomer, g.City
FROM BetsDetail as s
INNER JOIN BetsHeader as o
ON s.BetNumber = o.BetKey
INNER JOIN Customer as c
ON o.CustomerKey = c.CustomerKey
INNER JOIN Geography as g
ON c.GeographyKey = g.GeographyKey
GROUP BY c.FirstName, c.LastName, g.City
HAVING g.City = 'Roma'

--5 lista clienti nella citt� di Roma e et� maggiore di 40 anni
SELECT CONCAT(c.FirstName, c.LastName) as NameCustomer, c.Age, g.City
FROM BetsDetail as s
INNER JOIN BetsHeader as o
ON s.BetNumber = o.BetKey
INNER JOIN Customer as c
ON o.CustomerKey = c.CustomerKey
INNER JOIN Geography as g
ON c.GeographyKey = g.GeographyKey
GROUP BY c.FirstName, c.LastName, g.City, c.Age
HAVING g.City = 'Roma' AND c.Age > 40

--6 lista cliengi con flag vincita
SELECT CONCAT(c.FirstName, c.LastName) as NameCustomer,
  CASE 
	  WHEN s.CashWin > 0 THEN '1'
	  WHEN s.CashWin = 0 THEN '0'
	  END FlagAttivo
FROM BetsDetail as s
INNER JOIN BetsHeader as o
ON s.BetNumber = o.BetKey
INNER JOIN Customer as c
ON o.CustomerKey = c.CustomerKey

--7 lista giochi e ammontare scommesse nel 2023
SELECT SUM(s.MoneyWagered*s.Quantity) as BetsAmount, p.GameName
FROM BetsDetail as s
INNER JOIN Game as p
ON s.GameKey = p.GameKey
INNER JOIN BetsHeader as o
ON s.BetNumber = o.BetKey
WHERE YEAR(BetDate) = 2023
GROUP BY p.GameName
ORDER BY BetsAmount DESC

--DWH, creare views per PowerBI

CREATE VIEW MR_vDimGame AS (
SELECT p.Gamekey, p.GameName, p.GameCost, s.GameSubcategoryName, c.GameCategoryName
FROM Game as p
INNER JOIN GameSubcategory as s
ON p.GameSubcategoryKey = s.GameSubcategoryKey
INNER JOIN GameCategory as c
ON s.GameCategoryKey = c.GameCategoryKey);

CREATE VIEW MR_vFactBets AS ( 
SELECT s.BetNumber, s.BetLineNumber, s.MoneyWagered, s.Quantity, s.GameKey, s.CashWin, 
       o.BetDate, o.CustomerKey, c.GeographyKey
FROM BetsDetail AS s
INNER JOIN BetsHeader as o
ON s.BetNumber = o.BetKey
INNER JOIN Customer as c
ON o.CustomerKey = c.CustomerKey);

CREATE VIEW MR_vDimCustomer AS ( 
SELECT c.CustomerKey, CONCAT(FirstName, LastName) as NameCustomer, c.Birthday, c.Age, c.EmailAdress, c.Gender,
c.GeographyKey
FROM Customer as c);

CREATE VIEW MR_vDimGeography AS ( 
SELECT g.GeographyKey, g.City, g.Region, g.Country
FROM Geography as g);

